﻿using System.ComponentModel.DataAnnotations;
using System.Collections.Generic; // For List

namespace TrainingManagementSystem.Models.Entities
{
    public class CourseClassification : BaseEntity
    {
        [StringLength(100)]
        [Required]
        public string Name { get; set; }

        // العلاقة مع المدربين قد تكون many-to-many عبر جدول وسيط آخر إذا لم تكن مباشرة
        // أو قد تكون هذه القائمة للمدربين المؤهلين لتدريس هذا التصنيف.
        // إذا كانت العلاقة عبر TrainerSpecialization، فقد لا تحتاج لهذه القائمة هنا.
        public List<Trainer> Trainers { get; set; } = new List<Trainer>();

        public List<Course> Courses { get; set; } = new List<Course>();
    }
}