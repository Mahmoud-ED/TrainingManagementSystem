﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;

namespace TrainingManagementSystem.Models.Entities
{
    public class CourseTrainer : BaseEntity // Join table: Trainer (Many) <-> CourseDetails (Many)
    {
        [Required(ErrorMessage = "Trainer is required")]
        [Display(Name = "Trainer")]
        public Guid TrainerId { get; set; }
        [ValidateNever]
        public Trainer Trainer { get; set; }


        [Required(ErrorMessage = "CourseDetails is required")]
        [Display(Name = "Course Detail")]
        public Guid CourseDetailsId { get; set; }
        [ValidateNever]
        public CourseDetails CourseDetails { get; set; }
    }
}